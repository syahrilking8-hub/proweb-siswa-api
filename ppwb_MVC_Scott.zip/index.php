<?php
session_start();

// Load Controller
require_once __DIR__ . '/controllers/AuthController.php';
require_once __DIR__ . '/controllers/UserController.php';

// Tangkap action dari URL, default ke 'dashboard'
$action = $_GET['action'] ?? 'dashboard';

switch ($action) {
    // --- ROUTE AUTENTIKASI ---
    case 'login':
        $auth = new AuthController();
        $auth->login();
        break;

    case 'logout':
        $auth = new AuthController();
        $auth->logout();
        break;

    // --- ROUTE DASHBOARD & DATA WEB ---
    case 'dashboard':
        $user = new UserController();
        $user->dashboard();
        break;

    // --- ROUTE CRUD WEB (ADMIN) ---
    case 'store':
        $user = new UserController();
        $user->store();
        break;

    case 'update':
        $user = new UserController();
        $user->update();
        break;

    case 'delete':
        $user = new UserController();
        $user->delete();
        break;

    // --- FALLBACK (404 / REDIRECT) ---
    default:
        header('Location: index.php?action=dashboard');
        exit;
}
