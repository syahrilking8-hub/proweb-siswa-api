<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../models/UserModel.php';

$userModel = new UserModel();
$id = $_GET['id'] ?? null;

if ($id) {
    // Detail 1 data
    $student = $userModel->getStudentById($id);
    if ($student) {
        echo json_encode(["status" => "success", "message" => "Detail siswa ditemukan", "data" => $student], JSON_PRETTY_PRINT);
    } else {
        http_response_code(404);
        echo json_encode(["status" => "error", "message" => "Siswa tidak ditemukan"], JSON_PRETTY_PRINT);
    }
} else {
    // Semua data
    $students = $userModel->getAllStudents();
    echo json_encode(["status" => "success", "message" => "Data siswa berhasil diambil", "total" => count($students), "data" => $students], JSON_PRETTY_PRINT);
}
