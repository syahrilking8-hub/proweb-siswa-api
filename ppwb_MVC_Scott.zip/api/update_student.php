<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../models/UserModel.php';

// Izinkan method PUT maupun POST
$method = $_SERVER['REQUEST_METHOD'];

if ($method !== 'PUT' && $method !== 'POST') {
    http_response_code(405);
    echo json_encode(["status" => "error", "message" => "Method harus PUT atau POST"]);
    exit;
}

// Ambil input JSON dari Mini Postman
$input = json_decode(file_get_contents('php://input'), true);

$id = $input['id'] ?? $_POST['id'] ?? null;
$nis = $input['nis'] ?? $_POST['nis'] ?? '';
$nama = $input['nama'] ?? $_POST['nama'] ?? '';
$alamat = $input['alamat'] ?? $_POST['alamat'] ?? '';

if ($id && !empty($nis) && !empty($nama)) {
    $userModel = new UserModel();
    $userModel->updateStudent($id, $nis, $nama, $alamat);
    
    echo json_encode(["status" => "success", "message" => "Data siswa berhasil diperbarui"]);
} else {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "ID, NIS, dan Nama wajib diisi"]);
}
