<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../models/UserModel.php';

$method = $_SERVER['REQUEST_METHOD'];

// Ambil ID dari URL (?id=2) atau dari Body JSON
$input = json_decode(file_get_contents('php://input'), true);
$id = $_GET['id'] ?? $input['id'] ?? null;

if ($id) {
    $userModel = new UserModel();
    $userModel->deleteStudent($id);
    
    echo json_encode(["status" => "success", "message" => "Data siswa berhasil dihapus"]);
} else {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "ID siswa wajib disertakan"]);
}
