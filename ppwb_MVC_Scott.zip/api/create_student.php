<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../models/UserModel.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["status" => "error", "message" => "Method harus POST"]);
    exit;
}

// Ambil data JSON yang dikirim via Postman Body
$input = json_decode(file_get_contents('php://input'), true);

$nis = $input['nis'] ?? $_POST['nis'] ?? '';
$nama = $input['nama'] ?? $_POST['nama'] ?? '';
$alamat = $input['alamat'] ?? $_POST['alamat'] ?? '';

if (!empty($nis) && !empty($nama)) {
    $userModel = new UserModel();
    $userModel->createStudent($nis, $nama, $alamat);
    
    http_response_code(201);
    echo json_encode(["status" => "success", "message" => "Data siswa berhasil ditambahkan"]);
} else {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "NIS dan Nama wajib diisi"]);
}
