<?php
// Koneksi atau pembuatan file database SQLite
$db = new PDO('sqlite:' . __DIR__ . '/database.sqlite');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// 1. Buat Tabel Users (untuk Login)
$db->exec("CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT CHECK(role IN ('admin', 'user')) NOT NULL
)");

// 2. Buat Tabel Students (Data Siswa)
$db->exec("CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nis TEXT UNIQUE NOT NULL,
    nama TEXT NOT NULL,
    alamat TEXT NOT NULL
)");

// 3. Masukkan Data Sample (Seeder)
// Password default: 'password123' (di-hash dengan PASSWORD_BCRYPT)
$hashedPassword = password_hash('password123', PASSWORD_BCRYPT);

// Insert User Admin & User biasa
$stmtUser = $db->prepare("INSERT OR IGNORE INTO users (username, password, role) VALUES (:username, :password, :role)");
$stmtUser->execute([':username' => 'admin', ':password' => $hashedPassword, ':role' => 'admin']);
$stmtUser->execute([':username' => 'user', ':password' => $hashedPassword, ':role' => 'user']);

// Insert Data Siswa Contoh
$stmtStudent = $db->prepare("INSERT OR IGNORE INTO students (nis, nama, alamat) VALUES (:nis, :nama, :alamat)");
$stmtStudent->execute([':nis' => '1001', ':nama' => 'Budi Santoso', ':alamat' => 'Jl. Merdeka No. 12']);
$stmtStudent->execute([':nis' => '1002', ':nama' => 'Siti Nurhaliza', ':alamat' => 'Jl. Mawar No. 5']);

echo "Database dan tabel berhasil dibuat!";
