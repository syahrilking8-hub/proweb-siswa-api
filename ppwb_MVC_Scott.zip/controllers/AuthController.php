<?php
require_once __DIR__ . '/../models/UserModel.php';

class AuthController {
    private $userModel;

    public function __construct() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $this->userModel = new UserModel();
    }

    public function login() {
        // Jika sudah login, langsung lempar ke dashboard
        if (isset($_SESSION['user'])) {
            header('Location: index.php?action=dashboard');
            exit;
        }

        $error = null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';
            $selectedRole = $_POST['role'] ?? '';

            $user = $this->userModel->getUserByUsername($username);

            // Validasi keberadaan user, password hash, dan kesesuaian role dari dropdown
            if ($user && password_verify($password, $user['password'])) {
                if ($user['role'] === $selectedRole) {
                    $_SESSION['user'] = [
                        'id' => $user['id'],
                        'username' => $user['username'],
                        'role' => $user['role']
                    ];
                    header('Location: index.php?action=dashboard');
                    exit;
                } else {
                    $error = "Role yang dipilih tidak sesuai dengan akun Anda!";
                }
            } else {
                $error = "Username atau password salah!";
            }
        }

        require_once __DIR__ . '/../views/login.php';
    }

    public function logout() {
        session_destroy();
        header('Location: index.php?action=login');
        exit;
    }
}
