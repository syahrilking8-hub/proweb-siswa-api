<?php
require_once __DIR__ . '/../models/UserModel.php';

class UserController {
    private $userModel;

    public function __construct() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // Proteksi: Wajib login untuk akses dashboard web
        if (!isset($_SESSION['user'])) {
            header('Location: index.php?action=login');
            exit;
        }

        $this->userModel = new UserModel();
    }

    public function dashboard() {
        $students = $this->userModel->getAllStudents();
        $currentUser = $_SESSION['user'];
        
        require_once __DIR__ . '/../views/dashboard.php';
    }

    // --- FITUR CRUD WEB ---
    
    public function store() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nis = $_POST['nis'] ?? '';
            $nama = $_POST['nama'] ?? '';
            $alamat = $_POST['alamat'] ?? '';

            $this->userModel->createStudent($nis, $nama, $alamat);
            header('Location: index.php?action=dashboard');
            exit;
        }
    }

    public function update() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = $_POST['id'] ?? '';
            $nis = $_POST['nis'] ?? '';
            $nama = $_POST['nama'] ?? '';
            $alamat = $_POST['alamat'] ?? '';

            $this->userModel->updateStudent($id, $nis, $nama, $alamat);
            header('Location: index.php?action=dashboard');
            exit;
        }
    }

    public function delete() {
        $id = $_GET['id'] ?? null;
        if ($id) {
            $this->userModel->deleteStudent($id);
        }
        header('Location: index.php?action=dashboard');
        exit;
    }
}
