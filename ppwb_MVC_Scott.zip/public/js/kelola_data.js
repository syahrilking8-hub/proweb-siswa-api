document.addEventListener('DOMContentLoaded', () => {
    const studentModal = document.getElementById('studentModal');
    const deleteModal = document.getElementById('deleteModal');
    
    const btnAdd = document.getElementById('btnAddStudent');
    const btnCancelForm = document.getElementById('btnCancelForm');
    const btnCancelDelete = document.getElementById('btnCancelDelete');
    
    const studentForm = document.getElementById('studentForm');
    const modalTitle = document.getElementById('modalTitle');
    const inputId = document.getElementById('student_id');
    const inputNis = document.getElementById('nis');
    const inputNama = document.getElementById('nama');
    const inputAlamat = document.getElementById('alamat');
    
    const deleteText = document.getElementById('deleteText');
    const confirmDeleteLink = document.getElementById('confirmDeleteLink');

    // 1. Modal Tambah
    if (btnAdd) {
        btnAdd.addEventListener('click', () => {
            studentForm.action = 'index.php?action=store';
            modalTitle.textContent = 'Tambah Data Siswa';
            inputId.value = '';
            inputNis.value = '';
            inputNama.value = '';
            inputAlamat.value = '';
            studentModal.classList.add('is-open');
        });
    }

    // 2. Modal Edit (Isi otomatis form dengan data yang dipilih)
    document.querySelectorAll('.btn-edit').forEach(btn => {
        btn.addEventListener('click', () => {
            studentForm.action = 'index.php?action=update';
            modalTitle.textContent = 'Edit Data Siswa';
            inputId.value = btn.dataset.id;
            inputNis.value = btn.dataset.nis;
            inputNama.value = btn.dataset.nama;
            inputAlamat.value = btn.dataset.alamat;
            studentModal.classList.add('is-open');
        });
    });

    // 3. Modal Delete
    document.querySelectorAll('.btn-delete').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.dataset.id;
            const nama = btn.dataset.nama;
            deleteText.textContent = `Apakah Anda yakin ingin menghapus data "${nama}"?`;
            confirmDeleteLink.href = `index.php?action=delete&id=${id}`;
            deleteModal.classList.add('is-open');
        });
    });

    // Tutup Modal
    if (btnCancelForm) btnCancelForm.addEventListener('click', () => studentModal.classList.remove('is-open'));
    if (btnCancelDelete) btnCancelDelete.addEventListener('click', () => deleteModal.classList.remove('is-open'));
});
