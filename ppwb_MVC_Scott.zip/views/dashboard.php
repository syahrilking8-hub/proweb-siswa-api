<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portal Data Siswa</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="public/css/style.css">
    <link rel="stylesheet" href="public/css/login.css">
    <link rel="stylesheet" href="public/css/admin.css">
</head>
<body class="bg-slate-950 text-gray-100 min-h-screen relative overflow-x-hidden">

    <canvas id="particles-canvas"></canvas>

    <main class="relative z-10 max-w-5xl mx-auto px-4 py-8">
        
        <!-- Header TopBar -->
        <div class="flex items-center justify-between mb-8 pb-4 border-b border-slate-800">
            <div>
                <h1 class="text-2xl md:text-3xl font-extrabold text-white">Portal Data Siswa</h1>
                <p class="text-xs text-amber-400 font-medium tracking-widest uppercase mt-1">
                    Role: <span class="bg-amber-400/10 px-2 py-0.5 rounded text-amber-300"><?= htmlspecialchars($currentUser['role']); ?></span>
                </p>
            </div>
            <a href="index.php?action=logout" class="admin-btn btn-delete text-xs">
                Logout
            </a>
        </div>

        <!-- Toolbar Tambah Data -->
        <div class="mb-6">
            <button type="button" id="btnAddStudent" class="admin-btn">
                <svg fill="none" class="w-4 h-4" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>
                </svg>
                Tambah Siswa
            </button>
        </div>

        <!-- Tabel Data Siswa -->
        <div class="glow-card p-5 md:p-6">
            <div class="admin-table-wrap">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>NIS</th>
                            <th>Nama Siswa</th>
                            <th>Alamat</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($students)): ?>
                            <?php foreach ($students as $i => $s): ?>
                                <tr>
                                    <td><?= $i + 1; ?></td>
                                    <td class="font-semibold text-amber-400"><?= htmlspecialchars($s['nis']); ?></td>
                                    <td class="text-white"><?= htmlspecialchars($s['nama']); ?></td>
                                    <td><?= htmlspecialchars($s['alamat']); ?></td>
                                    <td>
                                        <div class="flex justify-center gap-2">
                                            <!-- Tombol Edit -->
                                            <button type="button" 
                                                    class="admin-btn btn-edit !py-1 !px-3 text-xs"
                                                    data-id="<?= $s['id']; ?>"
                                                    data-nis="<?= htmlspecialchars($s['nis']); ?>"
                                                    data-nama="<?= htmlspecialchars($s['nama']); ?>"
                                                    data-alamat="<?= htmlspecialchars($s['alamat']); ?>">
                                                Edit
                                            </button>
                                            <!-- Tombol Delete -->
                                            <button type="button" 
                                                    class="admin-btn btn-delete !py-1 !px-3 text-xs"
                                                    data-id="<?= $s['id']; ?>"
                                                    data-nama="<?= htmlspecialchars($s['nama']); ?>">
                                                Hapus
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center text-gray-400 py-8">
                                    Belum ada data siswa.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </main>

    <!-- Modal Form (Tambah/Edit) -->
    <div id="studentModal" class="modal-overlay">
        <div class="login-card w-full max-w-md">
            <h2 id="modalTitle" class="login-title">Tambah Data Siswa</h2>
            
            <form id="studentForm" method="POST" action="index.php?action=store">
                <input type="hidden" name="id" id="student_id">
                
                <div class="login-field">
                    <label for="nis">NIS</label>
                    <input type="text" name="nis" id="nis" required placeholder="Masukkan NIS">
                </div>
                
                <div class="login-field">
                    <label for="nama">Nama Siswa</label>
                    <input type="text" name="nama" id="nama" required placeholder="Masukkan Nama Lengkap">
                </div>
                
                <div class="login-field">
                    <label for="alamat">Alamat</label>
                    <input type="text" name="alamat" id="alamat" required placeholder="Masukkan Alamat">
                </div>

                <div class="flex gap-3 mt-6">
                    <button type="button" id="btnCancelForm" class="login-btn !bg-none !bg-slate-800 !text-white hover:!bg-slate-700">Batal</button>
                    <button type="submit" class="login-btn">Simpan</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Konfirmasi Hapus -->
    <div id="deleteModal" class="modal-overlay">
        <div class="login-card w-full max-w-sm text-center">
            <h2 class="login-title !mb-2">Hapus Data?</h2>
            <p id="deleteText" class="text-gray-300 text-sm mb-6">Apakah Anda yakin ingin menghapus data siswa ini?</p>
            
            <div class="flex gap-3">
                <button type="button" id="btnCancelDelete" class="login-btn !bg-none !bg-slate-800 !text-white hover:!bg-slate-700">Batal</button>
                <a id="confirmDeleteLink" href="#" class="login-btn !bg-gradient-to-r !from-red-600 !to-red-800 !text-white !shadow-red-900/50 flex items-center justify-center">Hapus</a>
            </div>
        </div>
    </div>

    <script src="public/js/particles.js"></script>
    <script src="public/js/kelola_data.js"></script>
</body>
</html>
