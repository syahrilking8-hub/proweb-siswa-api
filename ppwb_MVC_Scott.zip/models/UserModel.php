<?php
require_once __DIR__ . '/../config/database.php';

class UserModel {
    private $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    // --- AUTENTIKASI ---
    public function getUserByUsername($username) {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE username = :username");
        $stmt->execute([':username' => $username]);
        return $stmt->fetch();
    }

    // --- CRUD DATA SISWA ---
    public function getAllStudents() {
        $stmt = $this->db->query("SELECT * FROM students ORDER BY id DESC");
        return $stmt->fetchAll();
    }

    public function getStudentById($id) {
        $stmt = $this->db->prepare("SELECT * FROM students WHERE id = :id");
        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }

    public function createStudent($nis, $nama, $alamat) {
        $stmt = $this->db->prepare("INSERT INTO students (nis, nama, alamat) VALUES (:nis, :nama, :alamat)");
        return $stmt->execute([
            ':nis' => $nis,
            ':nama' => $nama,
            ':alamat' => $alamat
        ]);
    }

    public function updateStudent($id, $nis, $nama, $alamat) {
        $stmt = $this->db->prepare("UPDATE students SET nis = :nis, nama = :nama, alamat = :alamat WHERE id = :id");
        return $stmt->execute([
            ':id' => $id,
            ':nis' => $nis,
            ':nama' => $nama,
            ':alamat' => $alamat
        ]);
    }

    public function deleteStudent($id) {
        $stmt = $this->db->prepare("DELETE FROM students WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }
}
